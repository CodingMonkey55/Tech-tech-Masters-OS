#!/bin/bash
echo "Installing TechMasters OS..."

# Step 1: Clone repository
git clone https://github.com/yourusername/TechMastersOS.git /tmp/techmastersos || { echo "Failed to clone repository"; exit 1; }

cd /tmp/techmastersos || { echo "Repository directory not found"; exit 1; }

# Step 2: Install system dependencies
sudo apt update && sudo apt install -y python3 python3-pip libvirt-daemon-system qemu-kvm openbox xserver-xorg libgl1-mesa-dri

# Step 3: Install Python dependencies
pip3 install kivy pandas matplotlib flask-socketio libvirt-python

# Step 4: Copy files
sudo mkdir -p /opt/techmasters
sudo cp -r apps /opt/techmasters/
sudo cp -r themes /opt/techmasters/
sudo cp -r main_screens /opt/techmasters/
sudo cp main_launcher.py /opt/techmasters/

# Step 5: Configure launcher
sudo bash -c 'cat > /etc/systemd/system/techmasters.service <<EOF
[Unit]
Description=TechMasters OS Main Launcher
After=multi-user.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/techmasters/main_launcher.py
Restart=always

[Install]
WantedBy=multi-user.target
EOF'
sudo systemctl enable techmasters.service

echo "TechMasters OS installation complete! Reboot to launch."
